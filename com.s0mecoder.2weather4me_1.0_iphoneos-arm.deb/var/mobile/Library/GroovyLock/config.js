var city1 = "San Francisco, California";
var city2 = "San Diego, California";
var tempUnits = "f";