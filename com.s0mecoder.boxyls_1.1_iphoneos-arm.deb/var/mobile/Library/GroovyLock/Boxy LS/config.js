var weatherCity = "San Diego";
var tempUnits = "f";
var color = "cyan";
var AcceptedColors = "cyan, gray, red";
var clockLeadingZero = true;
