/**** Version 1, 6/13/15 ****/
function data()
{
        var percent = Math.round(groovyAPI.getBatteryLevel() * 100);
        var red = percent <= 20 ? 255 : 93;
        var blue = percent > 20 ? 83 : 0;
        var green = percent > 20 ? 214 : 0;
        document.getElementById("box").innerHTML = percent + "%";
        document.getElementById("box").style.backgroundColor = 'rgb(' + red + ', ' + green + ', ' + blue + ')';
        document.getElementById("box").style.width = percent + 1.5 + "%";
}
setInterval(data, 1000);
data();

/**** Written by /u/S0MECoder. Modify the code all you want but please leave this comment intact. PM me on Reddit if you redistribute this code or a modified version so I can check out what you've made! ****/