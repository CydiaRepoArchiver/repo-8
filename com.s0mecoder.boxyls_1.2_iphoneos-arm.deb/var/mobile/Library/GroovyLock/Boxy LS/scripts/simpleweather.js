$(document).ready(
    function() 
    {  
        getWeather();
        setInterval(getWeather, 60000);
    }
);

function getWeather() {
  $.simpleWeather({
    location: weatherCity,
    unit: tempUnits,
    success: function(weather) {
        document.getElementById("temp").innerHTML = weather.temp + "&deg"+ weather.units.temp +" "+ weather.currently;
        var w = weather.currently;
        var c = w.indexOf("unn") !==-1 ? "rbga(94, 218, 192, 0.6)" : w.indexOf("loud") !==-1 ? "rgba(169, 169, 169, 0.6)" : w.indexOf("air") !==-1 ? "rgba(34, 204, 255, 0.6)" : w.indexOf("ain") !==-1 ? "rgba(127, 127, 127, 0.6)" : "rbga(0, 204, 204, 0.6)";
        document.getElementById("temp").style.backgroundColor = c;
    },
    error: function(error) {
      $("#weather").html('<p>'+error+'</p>');
    }
  });
}
