var cityText = 'San Diego';
var clock24Hours = false;
var clockLeadingZero = false;