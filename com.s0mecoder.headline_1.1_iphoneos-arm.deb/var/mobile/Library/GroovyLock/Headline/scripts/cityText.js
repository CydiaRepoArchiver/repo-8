/**** Version 1, 6/18/25 ****/
function data()
{
    document.getElementById("cityText").innerHTML = ""+cityText;
}
setInterval(data, 1000);
data();

/**** Written by /u/S0MECoder. Modify the code all you want but please leave this comment intact. PM me on Reddit if you release this code or a modified version so I can check out what you've made! ****/