function init() {
}
function clickedGo() {
    var query = document.getElementById("search").value;
    query = query.replace(" ", "+");
    var url = "http" + engine + query;
    document.getElementById("search").value = "";
    document.getElementById("go").href = url;
}

function textFocused(focused) {
}