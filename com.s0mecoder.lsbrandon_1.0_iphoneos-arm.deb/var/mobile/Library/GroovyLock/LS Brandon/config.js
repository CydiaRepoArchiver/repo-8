var grayCircle = 1.0; // [0, 1] 0 = dark gray, 0.5 = light gray, 1 = white
var grayText = 0.0; // [0, 1] 0 = black, 0.5 = gray, 1 = white
var alpha = 0.9; // [0, 1] 0 = not opaque, 0.5 = half opaque, 1 = fully opaque