/**** Version custom, 6/18/25 ****/
function data() {
    var d = new Date();
    
    var a_hour = ["one", "two", "thr", "fou", "fiv", "six", "sev", "eig", "nin", "ten", "ele", "twe"];
    var a_mtens = ["zer", "one", "twe", "thi", "for", "fif"];
    var a_mones = ["zer", "one", "two", "thr", "fou", "fiv", "six", "sev", "eig", "nin"];
    var a_teens = ["thi", "fou", "fif", "six", "sev", "eig", "nin"];
    var h24 = d.getHours();
    var ampm = h24 > 12 ? "PM" : "AM";
    var h12 = h24 > 12 ? h24 - 12 : h24;
    var hour = a_hour[(h12 <= 0 ? 12 : h12) - 1];
    var m = d.getMinutes() < 10 ? "0" + d.getMinutes() : d.getMinutes();
    var teens = m > 12 && m < 20;
    var tens = teens ? a_teens[m - 13] : a_mtens[Math.floor(m / 10)];
    var ones = teens ? "tee" : a_mones[m % 10];
    document.getElementById("time").innerHTML = hour + "." + tens + "." + ones;
}
setInterval(data, 1000);
data();

/**** Written by /u/S0MECoder. Modify the code all you want but please leave this comment intact. PM me on Reddit if you release this code or a modified version so I can check out what you've made! ****/