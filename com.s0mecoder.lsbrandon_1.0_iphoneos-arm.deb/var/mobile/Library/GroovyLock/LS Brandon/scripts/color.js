function data()
{
    /****Mess with this part of you want full RGBA customization!****/
    var opacity = alpha;
    var colorHex = grayCircle * 255;
    var textGray = grayText * 255;
    document.getElementById("circle").style.backgroundColor = 'rgba('+colorHex+', '+colorHex+', '+colorHex+', '+opacity+')';
document.getElementById("time").style.color = 'rgb('+textGray+', '+textGray+', '+textGray+')';
}
setInterval(data, 1000);
data();

/**** Written by /u/S0MECoder. Modify the code all you want but please leave this comment intact. PM me on Reddit if you release this code or a modified version so I can check out what you've made! ****/