var clockLeadingZero = true;
var clock24Hours = false;
