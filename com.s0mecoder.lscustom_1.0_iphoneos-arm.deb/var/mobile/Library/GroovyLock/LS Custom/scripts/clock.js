/**** Version 2, 6/18/25 ****/
var d;
function data() {
    //Arrays
    var a_mon = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    var a_d = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
    var a_month = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    var a_day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    //Day number, short name, full name
    d = new Date();
    var day = d.getDay();
    var date = d.getDate();
    var weekDayAbbrev = a_d[day];
    var weekDayFull = a_day[day];
    //Month number, short name, full name
    var month = 1 + d.getMonth();
    var monthAbbrev = a_mon[month];
    var monthFull = a_month[month];
    //Year 4 digits, Year 2 digits
    var year = d.getFullYear();
    var year2D = year - 2000;
    //24h Hour, AM or PM, 12h Hour, Minutes, Seconds
    var h24 = d.getHours();
    var ampm = h24 > 12 ? "PM" : "AM";
    var h12 = h24 > 12 ? h24 - 12 : h24;
    var h = h12 <= 0 ? 12 : h12;
    h = clock24Hours ? h24 : h;
    h = clockLeadingZero ? (h < 10 ? "0" + h : h) : h;
    var m = d.getMinutes() < 10 ? "0" + d.getMinutes() : d.getMinutes();
    var s = d.getSeconds();
    var one = dayMonthYear ? date : month;
    var two = dayMonthYear ? month : date;
    document.body.style.fontFamily = font;
    document.body.style.fontSize = fontSize;
    document.getElementById("info").style.color = color;
    document.getElementById("info").style.marginTop = position;
    document.getElementById("time").innerHTML = h + time(h, h24, m) + m;
    document.getElementById("date").style.opacity = showDate ? 1.0 : 0.0;
    document.getElementById("date").innerHTML = one + date1(one, two, year2D) + two + date2(one, two, year2D) + year2D;
}
setInterval(data, 1000);
data();
function time(h, h24, m) {
    var sym;
    if (mathStyle) {
        sym = h > m ? '>' : h < m ? '<' : '=';
    }
    if (standardStyle) {
        sym = ':';
    }
    if (customStyle) {
        sym = eval(timeSymbol);
    }
    return sym;
}
function date1(m, d, year2D) {
    var sym;
    if (mathStyle) {
        sym = '+';
    }
    if (standardStyle) {
        sym = '/';
    }
    if (customStyle) {
        sym = eval(date1Symbol);
    }
    return sym;
}
function date2(m, d, y) {
    var sym;
    if (mathStyle) {
        sym = m + d == y ? '=' : '&ne;';
    }
    if (standardStyle) {
        sym = '/';
    }
    if (customStyle) {
        sym = eval(date2Symbol);
    }
    return sym;
}

/**** Written by /u/S0MECoder. Modify the code all you want but please leave this comment intact. PM me on Reddit if you release this code or a modified version so I can check out what you've made! ****/