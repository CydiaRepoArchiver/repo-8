/*
These variables are in their own file to combat a bug in both GroovyLock and LockHTML where these strings get messed up if they have an equals sign in them.
To find codes for characters you cannot type on a keyboard, visit http://www.ascii.cl/htmlcodes.htm
    For example: &ne; is the not-equal sign.
To customize the symbols in the clock and date you will use the javascript ternary operator, which I will explain how to use below, to specify what the symbol will be if the conditions you specify are true or false.
Advanced users: You have access to all of the javascript date functions with "d" being the Date variable. If you really want to use it, and you have it installed, then you can also use groovyAPI commands.

The variables you have easy access to are:

For setting the timeSymbol
    h - Current hour on 12 hour clock - ex: 6
    h24 - Current hour on 24 hour clock - ex: 18
    m - Current minute - ex: 34

For setting date1Symbol and date2Symbol
    m - Current month - 7
    d - Current day - 16
    y - Current abbreviated year - 15

The ternary operator can look confusing but is very simple.
First, you ask a question. For this example we can check if it is after 8am and before 6pm. Since we care about whether it is AM or PM we will use the hour from a 24 hour clock. This is written as:

(h24 > 8 && h24 < 18) ?

Those "&&" mean "and", and if we wanted to check whether it was either after 8am OR before 6pm, then it would have "||" instead. This question will either give the answer true or false. To specify what the symbol will be based on the answer to this question you will write something like the following after the question mark.

'☀' : '☽'

Now if it is after 8am and before 6pm, the symbol will be a sun, and if these conditions aren't met, then the symbol will be a moon.
The true and false answers are separated by a colon and must be in single-quotes as shown above.
To put these together so we can get this to actually work on our lock screen, we take the question and put it together with our answers.

(h24 > 8 && h24 < 18) ? '☀' : '☽'

To make sure this is understood properly by the program we will put double quotes on both ends of this question and answer line and end the line with a semicolon.

"(h24 > 8 && h24 < 18) ? '☀' : '☽'";

If we want this question and answer to determine the symbol between the hour and minute then you will put this line after the equals sign in the line that says timeSymbol so that it says:

var timeSymbol = "(h24 > 8 && h24 < 18) ? '☀' : '☽'";

Congratulations! You just made your time separator symbol change based on the time of day.
This will show the time on the lock screen as:
8☀30 if it is 8:30am, or
10☽20 if it is 10:20pm.
If you instead just wanted your symbol to always be the same, then choose what you want it to be:

#

Then put single quotes around this symbol:

'#'

Then also put double quotes around the single quotes and end the line with a semicolon:

"'#'";

And lastly, put this line after the equals sign for whatever you want this to be:

var date1Symbol = "'#'";

In this example we will set this symbol as the first separator for the date, if we want to set the second separator for the date then we can do the same thing with whatever we want that symbol to be.

var date2Symbol = "'^'";

If it is July 16, 2015, the date will show as:
7#16^15
If you followed these instructions correctly to make your custom theme, then you should have the following lines written below outside of this comment, (write it outside of the slash and apostrophe symbols).

var timeSymbol = "(h24 > 8 && h24 < 18) ? '☀' : '☽'";
var date1Symbol = "'#'";
var date2Symbol = "'^'";

Now that you understand the basic grammar you can dissect the code below to see more of what you can do. This includes more complex stuff like asking another question if the answer is false, as shown in the original timeSymbol. It is generally good practice to write the question in parentheses so it is easier to read.
*/
var timeSymbol = "(h > m) ? '>' : (h < m) ? '<' : '='";
var date1Symbol = "'+'";
var date2Symbol = "(m + d == y) ? '=' : '&ne;'";