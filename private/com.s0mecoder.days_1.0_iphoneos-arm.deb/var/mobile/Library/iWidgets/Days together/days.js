function data() {
    var message;
    //message = str1 + "&nbsp;" + daysUntil(date) + &nbsp; + "days&nbsp;" + str2;
    document.getElementById("content").innerHTML = str1 + "&nbsp;" + daysUntil(date) + "&nbsp;days&nbsp;" + str2;
}
setInterval(data, 1000);
data();

function daysUntil(date) {
    var d, t, u, s, n;
    d = new Date().getTime();
    s = date.split("-");
    t = Date.UTC(s[0], s[1] - 1, s[2]);
    u = Math.ceil((d - t)/1000/60/60/24);
    return u;
}